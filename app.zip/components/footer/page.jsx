const Footer = () => {
    return (
        <div className="md:bg-background w-full h-1/2 absolute -bottom-10 -z-10">
            
        </div>
    );
}

export default Footer;