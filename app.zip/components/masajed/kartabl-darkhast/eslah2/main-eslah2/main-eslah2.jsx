import HeaderEslah2 from "../header-eslah2/header-eslah2";
import MainGardesheslah2 from "../main-gardesh-eslah2/main-gardesh-eslah2";

const MainEslah2 = () => {
  return (
    <div className="bg-header-masjed bg-repeat-x bg-auto lg:bg-header-masjed-desktop lg:bg-no-repeat lg:bg-contain px-7">
      <HeaderEslah2 />
      <MainGardesheslah2/>
    </div>
  );
};

export default MainEslah2;
