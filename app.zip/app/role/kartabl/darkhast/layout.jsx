export default function RoleLayout({ children }) {
    return <>{children}</>;
  }