import MainKartablDarkhast from "../../../components/masajed/kartabl-darkhast/main-kartabl-darkhast/main-kartabl-darkhast";

const kartablDarkhast = () => {
  return (
    <>
      <MainKartablDarkhast />
    </>
  );
};

export default kartablDarkhast;
