import FooterMasajed from "../../../components/footer/page";


export default function kartablDarkhastLayout({ children }) {
  return (
    <>
        {children}
        <FooterMasajed />
    </>
  );
}
