import MainEslah2 from "../../../../components/masajed/kartabl-darkhast/eslah2/main-eslah2/main-eslah2";

const Eslah = () => {
    return (
        <MainEslah2/>
    );
}

export default Eslah;