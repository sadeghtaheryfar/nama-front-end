// import MainMoshahedeGozaresh from "@/components/masajed/kartabl-gozaresh/moshahede-gozaresh/main-moshahede-gozaresh/main-moshahede-gozaresh";
import MainMoshahedeGozaresh from "../../../../components/masajed/kartabl-gozaresh/moshahede-gozaresh/main-moshahede-gozaresh/main-moshahede-gozaresh";

const MoshahedeGozaresh = () => {
  return <MainMoshahedeGozaresh />;
};

export default MoshahedeGozaresh;
