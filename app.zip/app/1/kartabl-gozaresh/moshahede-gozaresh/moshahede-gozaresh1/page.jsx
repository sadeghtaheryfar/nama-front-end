// import MainMoshahedeGozaresh1 from "@/components/masajed/kartabl-gozaresh/moshahede-gozaresh1/main-moshahede-gozaresh1/main-moshahede-gozaresh1";
import MainMoshahedeGozaresh1 from "../../../../../components/masajed/kartabl-gozaresh/moshahede-gozaresh1/main-gardesh-moshahede1/main-gardesh-moshahede1";

const MoshahedeGozaresh1 = () => {
  return <MainMoshahedeGozaresh1 />;
};

export default MoshahedeGozaresh1;
