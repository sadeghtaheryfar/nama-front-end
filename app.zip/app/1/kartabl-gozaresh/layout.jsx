import FooterMasajed from "../../../components/masajed/footer/footer-masjed";


export default function kartablGozareshLayout({ children }) {
  return (
    <>
        {children}
        <FooterMasajed />
    </>
  );
}
