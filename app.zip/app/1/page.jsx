"use client";
import FooterMasajed from "../../components/masajed/footer/footer-masjed";
import MainMasajed from "../../components/masajed/main/main-masajed";

const Masajed = () => {
  return (
    <>
      <MainMasajed />
      <FooterMasajed />
    </>
  );
};

export default Masajed;
