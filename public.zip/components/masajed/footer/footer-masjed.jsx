"use client";
import Image from "next/image";

const FooterMasajed = () => {
  return (
    <div className="hidden md:block absolute -bottom-20 right-0 left-0 bg-background bg-cover w-full h-1/3 bg-no-repeat">
    </div>
  );
};

export default FooterMasajed;
