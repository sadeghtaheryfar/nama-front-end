// import MainRad from "@/components/masajed/kartabl-darkhast/radc/main-rad/main-rad";
import MainRad from "../../../../components/masajed/kartabl-darkhast/rad/main-rad/main-rad";

const Rad = () => {
  return <MainRad />;
};

export default Rad;
