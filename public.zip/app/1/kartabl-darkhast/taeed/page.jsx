// import MainTaeed from "@/components/masajed/kartabl-darkhast/taeed/main-taeed/main-taeed";
import MainTaeed from "../../../../components/masajed/kartabl-darkhast/taeed/main-taeed/main-taeed";

const Taeed = () => {
  return <MainTaeed />;
};

export default Taeed;
