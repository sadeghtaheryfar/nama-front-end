"use client";
import MainEslah from "../../../../components/masajed/kartabl-darkhast/eslah/main-eslah/main-eslah";

const Eslah = () => {
    return (
        <MainEslah/>
    );
}

export default Eslah;