// import FooterMasajed from "@/components/masajed/footer/footer-masjed";

export default function MasajedLayout({ children }) {
  return <>{children}</>;
}
