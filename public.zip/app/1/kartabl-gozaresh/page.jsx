import MainGozaresh from "../../../components/masajed/kartabl-gozaresh/main-gozaresh/main-gozaresh";

const KartablGozaresh = () => {
    return (
        <MainGozaresh/>
    );
}

export default KartablGozaresh;