// import MainMoshahedeGozaresh2 from "@/components/masajed/kartabl-gozaresh/moshahede-gozaresh2/main-moshahede-gozaresh2/main-moshahede-gozaresh2";
import MainMoshahedeGozaresh2 from "../../../../../../components/masajed/kartabl-gozaresh/moshahede-gozaresh2/main-moshahede-gozaresh2/main-moshahede-gozaresh2";

const MoshahedeGozaresh2 = () => {
  return <MainMoshahedeGozaresh2 />;
};

export default MoshahedeGozaresh2;
