import FooterMasajed from "../../../components/masajed/footer/footer-masjed";

export default function MaktobLayout({ children }) {
  return (
    <>
      {children}
      <FooterMasajed />
    </>
  );
}
