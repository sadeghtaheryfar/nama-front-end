import MainDarkhast from "../../../components/masajed/darkhast/main-darkhast/main-darkhast";
import FooterMasajed from "../../../components/masajed/footer/footer-masjed";

const Darkhast = () => {
  return (
    <>
      <MainDarkhast />
      <FooterMasajed />
    </>
  );
};

export default Darkhast;
