// import MainJari from "@/components/masajed/kartabl-darkhast/jari/main-jari/main-jari";
import MainJari from "../../../../components/masajed/kartabl-darkhast/jari/main-jari/main-jari";

const Jari = () => {
  return <MainJari />;
};

export default Jari;